# Life Expectancy Data

## Source

**Life Expectancy - Our World in Data**

By: Saloni Dattani, Lucas Rodés-Guirao, Hannah Ritchie, Esteban Ortiz-Ospina, and Max Roser

Published online at OurWorldinData.org. Retrieved from: 'https://ourworldindata.org/life-expectancy' [Online Resource]

## Data Description

This dataset contains life expectancy data from various sources compiled by Our World in Data:

- **Period life expectancy**: A metric that summarizes death rates across all age groups in one particular year
- **Time coverage**: From 1800 to 2021 for various countries
- **Geographic coverage**: Global, with data for most countries

## Data Sources

The data is compiled from three main sources:
1. **United Nations World Population Prospects (UN WPP)**: Data from 1950 onwards
2. **Zijdeman et al. (2015)**: Historical data before 1950
3. **Riley (2005)**: Pre-1950 data on world regions and global estimates
4. **Human Mortality Database (HMD)**: Additional historical data

## Citation

```
Saloni Dattani, Lucas Rodés-Guirao, Hannah Ritchie, Esteban Ortiz-Ospina, and Max Roser (2023) - "Life Expectancy" Published online at OurWorldinData.org. Retrieved from: 'https://ourworldindata.org/life-expectancy' [Online Resource]
```

## License

All visualizations, data, and code produced by Our World in Data are completely open access under the Creative Commons BY license. You have the permission to use, distribute, and reproduce these in any medium, provided the source and authors are credited.

## Data Files

- `life_expectancy.csv`: Life expectancy by country and year