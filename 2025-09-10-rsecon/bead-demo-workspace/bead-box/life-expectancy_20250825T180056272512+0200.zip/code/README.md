# Life Expectancy Data

## Source
**Our World in Data** - Life Expectancy Dataset  
https://ourworldindata.org/life-expectancy

## Citation
Max Roser, Esteban Ortiz-Ospina and Hannah Ritchie (2013) - "Life Expectancy". Published online at OurWorldInData.org. Retrieved from: 'https://ourworldindata.org/life-expectancy'

## License
All visualizations, data, and code produced by Our World in Data are completely open access under the Creative Commons BY license. You have the permission to use, distribute, and reproduce these in any medium, provided the source and authors are credited.

## Data Description
This dataset contains life expectancy at birth data for countries worldwide, compiled from multiple sources:
- United Nations World Population Prospects (UN WPP)
- Human Mortality Database (HMD)
- Zijdeman et al. (2015)
- Riley (2005)

Period life expectancy is a metric that summarizes death rates across all age groups in one particular year. For a given year, it represents the average lifespan for a hypothetical group of people, if they experienced the same age-specific death rates throughout their whole lives as the age-specific death rates seen in that particular year.

## Processing
Data downloaded from Our World in Data repository and saved in CSV format.