# GDP Per Capita Data

## Source

**World Development Indicators - The World Bank**

GDP per capita (constant 2015 US$)

Retrieved from World Bank Open Data API: https://api.worldbank.org/v2/

## Data Description

GDP per capita is gross domestic product divided by midyear population. GDP is the sum of gross value added by all resident producers in the economy plus any product taxes and minus any subsidies not included in the value of the products. It is calculated without making deductions for depreciation of fabricated assets or for depletion and degradation of natural resources. Data are in constant 2015 U.S. dollars.

## Indicator Details

- **Indicator Code**: NY.GDP.PCAP.KD
- **Indicator Name**: GDP per capita (constant 2015 US$)
- **Source**: World Development Indicators
- **Periodicity**: Annual
- **Base Period**: 2015

## Data Coverage

- **Temporal Coverage**: 1960 to present (varies by country)
- **Geographic Coverage**: All World Bank member countries and economies with populations greater than 30,000

## Citation

World Bank. (2024). World Development Indicators: GDP per capita (constant 2015 US$) [Data file]. Retrieved from https://data.worldbank.org/indicator/NY.GDP.PCAP.KD

## License

The World Bank Group makes data publicly available according to open data standards and licenses datasets under the Creative Commons Attribution 4.0 International license (CC BY 4.0).

## Data Files

- `gdp_per_capita.csv`: GDP per capita by country and year in constant 2015 US$